CREATE DATABASE  IF NOT EXISTS `podsistem2` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `podsistem2`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: podsistem2
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `artikl`
--

DROP TABLE IF EXISTS `artikl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `artikl` (
  `IDArt` int NOT NULL AUTO_INCREMENT,
  `Naziv` varchar(100) NOT NULL,
  `Opis` varchar(100) DEFAULT NULL,
  `Cena` double NOT NULL,
  `Popust` double NOT NULL,
  `IDKor` int NOT NULL,
  `IDKat` int NOT NULL,
  PRIMARY KEY (`IDArt`),
  KEY `IDKor` (`IDKor`),
  KEY `IDKat` (`IDKat`),
  CONSTRAINT `artikl_ibfk_1` FOREIGN KEY (`IDKor`) REFERENCES `podsistem1`.`korisnik` (`IDKor`) ON DELETE CASCADE,
  CONSTRAINT `artikl_ibfk_2` FOREIGN KEY (`IDKat`) REFERENCES `kategorija` (`IDKat`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artikl`
--

LOCK TABLES `artikl` WRITE;
/*!40000 ALTER TABLE `artikl` DISABLE KEYS */;
INSERT INTO `artikl` VALUES (13,'lopta','lopta',100,10,10,8),(14,'patike','patike za kosarku',200,0,10,10),(15,'dres','dres',100,10,10,10),(16,'komp','komp',100,5,11,9),(17,'tastatura','tastatura',100,0,11,11),(18,'monitor','monitor',65,10,11,9),(19,'slusalice','slusalice',30,0,12,12),(20,'mikrofon','mikrofon',60,30,12,12);
/*!40000 ALTER TABLE `artikl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kategorija`
--

DROP TABLE IF EXISTS `kategorija`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kategorija` (
  `IDKat` int NOT NULL AUTO_INCREMENT,
  `Naziv` varchar(100) NOT NULL,
  `NadKat` int DEFAULT NULL,
  PRIMARY KEY (`IDKat`),
  KEY `NadKat` (`NadKat`),
  CONSTRAINT `kategorija_ibfk_1` FOREIGN KEY (`NadKat`) REFERENCES `kategorija` (`IDKat`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kategorija`
--

LOCK TABLES `kategorija` WRITE;
/*!40000 ALTER TABLE `kategorija` DISABLE KEYS */;
INSERT INTO `kategorija` VALUES (8,'Sport',NULL),(9,'Faks',NULL),(10,'Kosarka',8),(11,'Programiranje',9),(12,'Igrice',NULL),(13,'Fudbal',8),(14,'nba',10);
/*!40000 ALTER TABLE `kategorija` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `korpa`
--

DROP TABLE IF EXISTS `korpa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `korpa` (
  `IDKorpa` int NOT NULL,
  `UkupnaCena` double NOT NULL,
  PRIMARY KEY (`IDKorpa`),
  CONSTRAINT `korpa_ibfk_1` FOREIGN KEY (`IDKorpa`) REFERENCES `podsistem1`.`korisnik` (`IDKor`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `korpa`
--

LOCK TABLES `korpa` WRITE;
/*!40000 ALTER TABLE `korpa` DISABLE KEYS */;
INSERT INTO `korpa` VALUES (10,0),(11,0),(12,90),(13,585),(14,0),(15,270);
/*!40000 ALTER TABLE `korpa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recenzija`
--

DROP TABLE IF EXISTS `recenzija`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recenzija` (
  `IDRec` int NOT NULL AUTO_INCREMENT,
  `IDKor` int NOT NULL,
  `IDArt` int NOT NULL,
  `Ocena` int NOT NULL,
  `Opis` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`IDRec`),
  KEY `IDKor` (`IDKor`),
  KEY `IDArt` (`IDArt`),
  CONSTRAINT `recenzija_ibfk_1` FOREIGN KEY (`IDKor`) REFERENCES `podsistem1`.`korisnik` (`IDKor`) ON DELETE CASCADE,
  CONSTRAINT `recenzija_ibfk_2` FOREIGN KEY (`IDArt`) REFERENCES `artikl` (`IDArt`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recenzija`
--

LOCK TABLES `recenzija` WRITE;
/*!40000 ALTER TABLE `recenzija` DISABLE KEYS */;
/*!40000 ALTER TABLE `recenzija` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sadrzi`
--

DROP TABLE IF EXISTS `sadrzi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sadrzi` (
  `IDArt` int NOT NULL,
  `IDKorpa` int NOT NULL,
  `Cena` double NOT NULL,
  `Kolicina` int NOT NULL,
  PRIMARY KEY (`IDArt`,`IDKorpa`),
  KEY `IDKorpa` (`IDKorpa`),
  CONSTRAINT `sadrzi_ibfk_1` FOREIGN KEY (`IDArt`) REFERENCES `artikl` (`IDArt`) ON DELETE CASCADE,
  CONSTRAINT `sadrzi_ibfk_2` FOREIGN KEY (`IDKorpa`) REFERENCES `korpa` (`IDKorpa`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sadrzi`
--

LOCK TABLES `sadrzi` WRITE;
/*!40000 ALTER TABLE `sadrzi` DISABLE KEYS */;
INSERT INTO `sadrzi` VALUES (13,12,90,1),(13,13,90,1),(13,15,90,3),(14,13,200,2),(16,13,95,1);
/*!40000 ALTER TABLE `sadrzi` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-21 13:32:24
