CREATE DATABASE  IF NOT EXISTS `podsistem3` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `podsistem3`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: podsistem3
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `narudzbina`
--

DROP TABLE IF EXISTS `narudzbina`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `narudzbina` (
  `IDNar` int NOT NULL AUTO_INCREMENT,
  `UkupnaCena` double NOT NULL,
  `VremeKreiranja` datetime NOT NULL,
  `Adresa` varchar(100) NOT NULL,
  `IDGrad` int NOT NULL,
  `IDKor` int NOT NULL,
  PRIMARY KEY (`IDNar`),
  KEY `IDGrad` (`IDGrad`),
  KEY `IDKor` (`IDKor`),
  CONSTRAINT `narudzbina_ibfk_1` FOREIGN KEY (`IDGrad`) REFERENCES `podsistem1`.`grad` (`IDGrad`) ON DELETE CASCADE,
  CONSTRAINT `narudzbina_ibfk_2` FOREIGN KEY (`IDKor`) REFERENCES `podsistem1`.`korisnik` (`IDKor`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `narudzbina`
--

LOCK TABLES `narudzbina` WRITE;
/*!40000 ALTER TABLE `narudzbina` DISABLE KEYS */;
INSERT INTO `narudzbina` VALUES (39,315,'2023-02-20 15:14:08','adresa',7,15),(40,90,'2023-02-20 15:14:59','adresa',7,15),(41,90,'2023-02-20 15:15:04','adresa',7,15),(42,785,'2023-02-20 15:20:31','adresa 5',9,14),(43,90,'2023-02-20 15:22:02','adresa 5',9,14),(44,180,'2023-02-20 15:25:13','adresa 5',9,14),(45,88.5,'2023-02-20 16:21:46','Adresa nova 2',3,10),(46,88.5,'2023-02-20 16:23:04','Adresa nova 2',3,10),(47,190,'2023-02-21 10:47:52','Adresa nova 2',3,10),(48,380,'2023-02-21 10:52:20','adresa 2',3,11),(49,95,'2023-02-21 13:21:52','Adresa nova 2',3,10),(50,212,'2023-02-21 13:22:07','Adresa nova 2',3,10),(51,58.5,'2023-02-21 13:24:16','Adresa nova 2',3,10);
/*!40000 ALTER TABLE `narudzbina` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stavka`
--

DROP TABLE IF EXISTS `stavka`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stavka` (
  `IDStavka` int NOT NULL AUTO_INCREMENT,
  `IDNar` int NOT NULL,
  `IDArt` int NOT NULL,
  `Kolicina` int NOT NULL,
  `Cena` double NOT NULL,
  PRIMARY KEY (`IDStavka`),
  KEY `IDNar` (`IDNar`),
  KEY `IDArt` (`IDArt`),
  CONSTRAINT `stavka_ibfk_1` FOREIGN KEY (`IDNar`) REFERENCES `narudzbina` (`IDNar`) ON DELETE CASCADE,
  CONSTRAINT `stavka_ibfk_2` FOREIGN KEY (`IDArt`) REFERENCES `podsistem2`.`artikl` (`IDArt`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stavka`
--

LOCK TABLES `stavka` WRITE;
/*!40000 ALTER TABLE `stavka` DISABLE KEYS */;
INSERT INTO `stavka` VALUES (49,39,13,2,180),(50,39,15,3,135),(51,40,13,1,90),(52,41,13,1,90),(53,42,14,3,600),(54,42,15,2,90),(55,42,16,1,95),(56,43,13,1,90),(57,44,13,2,180),(58,45,18,1,58.5),(59,45,19,1,30),(60,46,18,1,58.5),(61,46,19,1,30),(62,47,16,2,190),(63,48,13,2,180),(64,48,14,1,200),(65,49,16,1,95),(66,50,16,1,95),(67,50,18,2,117),(68,51,18,1,58.5);
/*!40000 ALTER TABLE `stavka` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transakcija`
--

DROP TABLE IF EXISTS `transakcija`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transakcija` (
  `IDTrans` int NOT NULL AUTO_INCREMENT,
  `Suma` double NOT NULL,
  `IDNar` int NOT NULL,
  `VremePlacanja` datetime NOT NULL,
  PRIMARY KEY (`IDTrans`),
  KEY `IDNar` (`IDNar`),
  CONSTRAINT `transakcija_ibfk_1` FOREIGN KEY (`IDNar`) REFERENCES `narudzbina` (`IDNar`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transakcija`
--

LOCK TABLES `transakcija` WRITE;
/*!40000 ALTER TABLE `transakcija` DISABLE KEYS */;
INSERT INTO `transakcija` VALUES (39,315,39,'2023-02-20 15:14:08'),(40,90,40,'2023-02-20 15:14:59'),(41,90,41,'2023-02-20 15:15:04'),(42,785,42,'2023-02-20 15:20:31'),(43,90,43,'2023-02-20 15:22:02'),(44,180,44,'2023-02-20 15:25:13'),(45,88.5,45,'2023-02-20 16:21:47'),(46,88.5,46,'2023-02-20 16:23:04'),(47,190,47,'2023-02-21 10:47:52'),(48,380,48,'2023-02-21 10:52:20'),(49,95,49,'2023-02-21 13:21:52'),(50,212,50,'2023-02-21 13:22:07'),(51,58.5,51,'2023-02-21 13:24:16');
/*!40000 ALTER TABLE `transakcija` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-21 13:32:30
